﻿using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Text;
using IDComplete.Utilities;
using IDComplete.Entities;
using IDComplete.Interfaces;
using System.Data;
using IDComplete.DataSources;
using Newtonsoft.Json;

namespace Tests
{
    public class AgeCalculationTests
    {
        private AgeCalculation ageCalc = new AgeCalculation();

        [Test]
        public void AgeCalculation_1()
        {
            DateTime calcDate = new DateTime(2020, 3, 30);

            var output = ageCalc.execute("8505020067088", calcDate);
            Assert.AreEqual(34, output);
        }

        [Test]
        public void AgeCalculation_2()
        {
            DateTime calcDate = new DateTime(2020, 5, 13);

            var output = ageCalc.execute("8505020067088", calcDate);
            Assert.AreEqual(35, output);
        }

        [Test]
        public void AgeCalculation_3()
        {
            DateTime calcDate = new DateTime(2020, 5, 13);

            var output = ageCalc.execute("8505130067088", calcDate);
            Assert.AreEqual(35, output);
        }

        [Test]
        public void AgeCalculation_4()
        {
            DateTime calcDate = new DateTime(2020, 5, 13);

            var output = ageCalc.execute("0005020067088", calcDate);
            Assert.AreEqual(20, output);
        }

        [Test]
        public void AgeCalculation_LeapYear1()
        {
            DateTime calcDate = new DateTime(2020, 5, 13);

            var output = ageCalc.execute("0002290067088", calcDate);
            Assert.AreEqual(20, output);
        }

        [Test]
        public void AgeCalculation_LeapYear2()
        {
            DateTime calcDate = new DateTime(2020, 5, 13);

            var output = ageCalc.execute("0002290067088", calcDate);
            Assert.AreEqual(20, output);
        }
    }
}
