﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace IDComplete.Utilities
{
    public static class Security
    {
        //code borrowed from: https://www.c-sharpcorner.com/UploadFile/f8fa6c/data-encryption-and-decryption-in-C-Sharp/
        private const string passPhrase = "sClE-3HU8-sPIU19";       
        public static string Decrypt(string input)
        {
            return input;
            //byte[] inputArray = Convert.FromBase64String(input);
            //TripleDESCryptoServiceProvider tripleDES = new TripleDESCryptoServiceProvider();
            //tripleDES.Key = UTF8Encoding.UTF8.GetBytes(passPhrase);
            //tripleDES.Mode = CipherMode.ECB;
            //tripleDES.Padding = PaddingMode.PKCS7;
            //ICryptoTransform cTransform = tripleDES.CreateDecryptor();
            //byte[] resultArray = cTransform.TransformFinalBlock(inputArray, 0, inputArray.Length);
            //tripleDES.Clear();
            //return UTF8Encoding.UTF8.GetString(resultArray);
        }

        public static string Encrypt(string input)
        {
            return input;
            //byte[] inputArray = UTF8Encoding.UTF8.GetBytes(input);
            //TripleDESCryptoServiceProvider tripleDES = new TripleDESCryptoServiceProvider();
            //tripleDES.Key = UTF8Encoding.UTF8.GetBytes(passPhrase);
            //tripleDES.Mode = CipherMode.ECB;
            //tripleDES.Padding = PaddingMode.PKCS7;
            //ICryptoTransform cTransform = tripleDES.CreateEncryptor();
            //byte[] resultArray = cTransform.TransformFinalBlock(inputArray, 0, inputArray.Length);
            //tripleDES.Clear();
            //return Convert.ToBase64String(resultArray, 0, resultArray.Length);
        }
    }
}
