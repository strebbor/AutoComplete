﻿using IDComplete.DataSources;
using IDComplete.Entities;
using IDComplete.Interfaces;
using IDComplete.Utilities;
using System.Collections.Generic;
using System.Data;
using System.Windows.Forms;

namespace IDComplete.CustomControls
{
    public partial class LookupScreen : Form
    {
        public delegate void delRowSelected(List<KeyValuePair<string, string>> rowValues);
        public event delRowSelected RowSelected;

        public delegate string delRowUpdated(DataRow dataRow, bool ensureUnique);
        public event delRowUpdated RowUpdated;

        public delegate void delRowDeleted(DataRow dataRow);
        public event delRowDeleted RowDeleted;

        private DataSyncLogic datasyncer;
        private ColumnSetup _primaryKeyColumn;

        private string _searchText;
        public string SearchText
        {
            get
            {
                return _searchText;
            }

            set
            {
                _searchText = value;
                SetDataInGrid(_searchText);
            }
        }

        private IDataSource _columnSetupDataSource;
        private DataTable dtLookupData;
        private DataTable _dataSource;
        public DataTable DataSource
        {
            get
            {
                return _dataSource;
            }
            set
            {
                _dataSource = value;
            }

        }
        public LookupScreen(IDataSource columnSetupDataSource, DataTable dataSource)
        {
            _dataSource = dataSource;
            _columnSetupDataSource = columnSetupDataSource;
            datasyncer = new DataSyncLogic(true, columnSetupDataSource);
            _primaryKeyColumn = _columnSetupDataSource.GetIdentifier<ColumnSetup>();

            InitializeComponent();

            gridData.ClearSelection();
        }
        private void SetDataInGrid(string textToMatch)
        {
            dtLookupData = _dataSource;
            dtLookupData.Columns.Remove("entryId");

            var matches = dtLookupData.Select(_primaryKeyColumn.Key + " LIKE '" + textToMatch + "%'");

            DataTable dtFilteredTable = dtLookupData.Clone();
            foreach (DataRow dr in matches)
            {
                var updatedRow = datasyncer.DoRowCalculations(dr);
                dtFilteredTable.ImportRow(updatedRow);
            }
            gridData.DataSource = dtFilteredTable;
        }

        private void GridData_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                PublishRowSelected();
                Hide();
            }

            if (e.KeyCode == Keys.Escape)
            {
                Hide();
            }
        }

        private List<KeyValuePair<string, string>> GetResponseObjects(DataGridViewRow currentRow)
        {
            List<KeyValuePair<string, string>> responseObjects = new List<KeyValuePair<string, string>>();

            foreach (var cell in currentRow.Cells)
            {
                var cellObject = (DataGridViewTextBoxCell)cell;
                var key = gridData.Columns[cellObject.ColumnIndex].DataPropertyName;
                var value = cellObject.Value.ToString();

                KeyValuePair<string, string> cellValue = new KeyValuePair<string, string>(key, value);
                responseObjects.Add(cellValue);
            }

            return responseObjects;
        }
        private void PublishRowSelected()
        {
            if (gridData.Rows.Count > 0)
            {
                var responseObject = GetResponseObjects(gridData.CurrentRow);
                RowSelected(responseObject);
            }
        }

        private void GridData_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            PublishRowSelected();
            Hide();
        }

        private void gridData_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            bool ensureUnique = false;

            DataRow row = ((DataRowView)gridData.CurrentRow.DataBoundItem).Row;

            var updatedRow = datasyncer.DoRowCalculations(row);

            //if (e.ColumnIndex == _primaryKeyColumn.ColumnNumber)
            //{
            //    //need to ensure uniqueness
            //    ensureUnique = true;
            //}

            string result = RowUpdated(updatedRow, ensureUnique);

            if (!string.IsNullOrWhiteSpace(result))
            {
                //something went wrong with the update, refresh the screen and display message
                MessageBox.Show("Failure updating record: " + result);
                SetDataInGrid(_searchText);
            }
        }

        private void deleteRowToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            if (selectedRow < 0) { return; }

            if (MessageBox.Show("Are you sure you want to delete this row?", "Confirmation", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                //delete from database
                DataRow row = ((DataRowView)gridData.Rows[selectedRow].DataBoundItem).Row;
                RowDeleted(row);
                gridData.Rows.RemoveAt(selectedRow);
            }
        }

        private int selectedRow = -1;
        private void gridData_CellMouseDown(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right)
            {
                selectedRow = e.RowIndex;
                gridData.Rows[selectedRow].Selected = true;
            }
        }
    }
}
