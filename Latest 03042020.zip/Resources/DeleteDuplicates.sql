  WITH cte AS (
    SELECT 
        idnumber, firstname, lastname, club, province, age, gender,
        ROW_NUMBER() OVER (
            PARTITION BY 
                idnumber
            ORDER BY 
                idnumber
        ) row_num
     FROM 
        Entries
)
DELETE FROM cte
WHERE row_num > 1;