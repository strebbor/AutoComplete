﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IDComplete.Entities
{
    public class SheetSetup
    {
        public string TriggerChar { get; set; }
        public string FirstRow { get; set; }
    }
}
