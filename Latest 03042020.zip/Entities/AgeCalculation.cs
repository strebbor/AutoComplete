﻿using IDComplete.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IDComplete.Entities
{
    public class AgeCalculation : ICalculationType
    {
        public object execute(string inputValue, object additional = null)
        {
            if (string.IsNullOrWhiteSpace(inputValue))
            {
                return "";
            }

            if (inputValue.Length < 13)
            {
                return "";
            }

            try
            {
                var currentDate = DateTime.Now;
                if (additional != null)
                {
                    currentDate = DateTime.Parse(additional.ToString());
                }

                DateTime birthDate = GetBirthDate(inputValue, DateTime.Now);
                return GetAge(currentDate, birthDate);
            }
            catch (Exception ee)
            {
                return "";
            }             
        }

        public DateTime GetBirthDate(string idNumber, DateTime currentDate)
        {
            var birthYear = int.Parse(idNumber.Substring(0, 2));
            var birthMonth = int.Parse(idNumber.Substring(2, 2));
            var birthDay = int.Parse(idNumber.Substring(4, 2));

            if (birthYear <= int.Parse(currentDate.Year.ToString().Substring(2)))
            {
                birthYear = int.Parse(("20" + birthYear).PadRight(4, '0'));
            }
            else
            {
                birthYear = int.Parse("19" + birthYear);
            }

            DateTime birthDate = new DateTime(birthYear, birthMonth, birthDay);
            return birthDate;
        }

        public object GetAge(DateTime useDate, DateTime dateOfBirth)
        {
            DateTime today = useDate;

            int months = today.Month - dateOfBirth.Month;
            int years = today.Year - dateOfBirth.Year;

            if (today.Day < dateOfBirth.Day)
            {
                months--;
            }

            if (months < 0)
            {
                years--;
                months += 12;
            }

            int days = (today - dateOfBirth.AddMonths((years * 12) + months)).Days;

            return years;
        }
    }
}
